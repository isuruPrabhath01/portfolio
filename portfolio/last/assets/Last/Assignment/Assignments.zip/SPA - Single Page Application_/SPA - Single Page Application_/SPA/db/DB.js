var customerAr=[];
var itemAr=[];
var tempOrderCartAr=[];
var orders=[];

