
function itemModal(itmCode,itemName,qtOHand,itPrice) {
    var itemObject={
        itemCode:itmCode,
        itemName:itemName,
        qtyOnHand:qtOHand,
        itemPrice:itPrice
    }
    itemAr.push(itemObject);
}

