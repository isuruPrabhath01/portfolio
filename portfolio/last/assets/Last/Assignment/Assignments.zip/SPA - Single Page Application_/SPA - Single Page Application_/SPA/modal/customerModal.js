
function customerModal(customerID,customerName,customerAddress,customerSalary) {
    var customer={
        cusId:customerID,
        cusName:customerName,
        cusAddress:customerAddress,
        cusSalary:customerSalary
    }
    customerAr.push(customer);
}

